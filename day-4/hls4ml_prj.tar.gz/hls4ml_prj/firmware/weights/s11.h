//Numpy array shape [1]
//Min 0.015625000000
//Max 0.125000000000
//Number of zeros 0

#ifndef S11_H_
#define S11_H_

#ifndef __SYNTHESIS__
exponent_scale11_t s11[8];
#else
exponent_scale11_t s11[8] = {{1.0, -6}, {1.0, -3}, {1.0, -3}, {1.0, -6}, {1.0, -6}, {1.0, -6}, {1.0, -5}, {1.0, -5}};
#endif

#endif
