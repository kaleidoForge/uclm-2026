//Numpy array shape [4, 2]
//Min -3.277211666107
//Max 3.301523208618
//Number of zeros 0

#ifndef W9_H_
#define W9_H_

#ifndef __SYNTHESIS__
q_dense_2_weight_t w9[8];
#else
q_dense_2_weight_t w9[8] = {0.0325283222, 0.7809262276, 3.3015232086, -2.3665666580, -3.2772116661, 1.9705897570, -3.0888490677, 2.8904187679};
#endif

#endif
