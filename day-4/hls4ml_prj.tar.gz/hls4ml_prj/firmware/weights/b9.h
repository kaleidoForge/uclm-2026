//Numpy array shape [2]
//Min -0.992694973946
//Max 0.992713570595
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
q_dense_2_bias_t b9[2];
#else
q_dense_2_bias_t b9[2] = {0.9927135706, -0.9926949739};
#endif

#endif
