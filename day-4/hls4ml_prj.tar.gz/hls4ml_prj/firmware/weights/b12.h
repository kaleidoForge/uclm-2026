//Numpy array shape [4]
//Min 0.000000000000
//Max 0.375000000000
//Number of zeros 1

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[4];
#else
bias12_t b12[4] = {0.000, 0.125, 0.125, 0.375};
#endif

#endif
