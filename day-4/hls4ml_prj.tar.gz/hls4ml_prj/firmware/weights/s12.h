//Numpy array shape [1]
//Min 0.062500000000
//Max 0.125000000000
//Number of zeros 0

#ifndef S12_H_
#define S12_H_

#ifndef __SYNTHESIS__
exponent_scale12_t s12[4];
#else
exponent_scale12_t s12[4] = {{1.0, -4}, {1.0, -3}, {1.0, -4}, {1.0, -4}};
#endif

#endif
