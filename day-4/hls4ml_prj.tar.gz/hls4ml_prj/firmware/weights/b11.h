//Numpy array shape [8]
//Min -0.125000000000
//Max 0.250000000000
//Number of zeros 4

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[8];
#else
bias11_t b11[8] = {0.000, 0.250, 0.250, 0.000, 0.000, 0.000, 0.250, -0.125};
#endif

#endif
