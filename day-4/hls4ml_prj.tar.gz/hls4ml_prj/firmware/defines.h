#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 161
#define N_SIZE_0_2 161
#define N_LAYER_3 8
#define N_LAYER_3 8
#define N_LAYER_3 8
#define N_LAYER_6 4
#define N_LAYER_6 4
#define N_LAYER_6 4
#define N_LAYER_9 2
#define N_LAYER_9 2

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,6> input_t;
typedef ap_fixed<16,6> model_default_t;
typedef ap_fixed<16,6> layer3_t;
typedef ap_fixed<8,5> weight3_t;
typedef ap_fixed<8,5> bias3_t;
typedef ap_uint<1> layer3_index;
typedef ap_fixed<16,6> layer11_t;
typedef struct exponent_scale11_t {ap_uint<1> sign;ap_int<7> weight; } exponent_scale11_t;
typedef ap_fixed<8,5> bias11_t;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT> layer5_t;
typedef ap_fixed<18,8> q_activation_table_t;
typedef ap_fixed<16,6> layer6_t;
typedef ap_fixed<8,5> weight6_t;
typedef ap_fixed<8,5> bias6_t;
typedef ap_uint<1> layer6_index;
typedef ap_fixed<16,6> layer12_t;
typedef struct exponent_scale12_t {ap_uint<1> sign;ap_int<5> weight; } exponent_scale12_t;
typedef ap_fixed<8,5> bias12_t;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT> layer8_t;
typedef ap_fixed<18,8> q_activation_1_table_t;
typedef ap_fixed<16,6> layer9_t;
typedef ap_fixed<16,6> q_dense_2_weight_t;
typedef ap_fixed<16,6> q_dense_2_bias_t;
typedef ap_uint<1> layer9_index;
typedef ap_fixed<16,6> result_t;
typedef ap_fixed<18,8> q_dense_2_softmax_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT> q_dense_2_softmax_exp_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT> q_dense_2_softmax_inv_table_t;

#endif
