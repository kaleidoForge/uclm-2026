#include <iostream>

#include "myproject.h"
#include "parameters.h"

void myproject(
    input_t flatten_input[N_INPUT_1_1],
    result_t layer10_out[N_LAYER_9]
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS ARRAY_RESHAPE variable=flatten_input complete dim=0
    #pragma HLS ARRAY_PARTITION variable=layer10_out complete dim=0
    #pragma HLS INTERFACE ap_vld port=flatten_input,layer10_out 
    #pragma HLS PIPELINE 

#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        // hls-fpga-machine-learning insert load weights
        nnet::load_weights_from_txt<weight3_t, 1288>(w3, "w3.txt");
        nnet::load_weights_from_txt<bias3_t, 8>(b3, "b3.txt");
        nnet::load_exponent_weights_from_txt<exponent_scale11_t, 8>(s11, "s11.txt");
        nnet::load_weights_from_txt<bias11_t, 8>(b11, "b11.txt");
        nnet::load_weights_from_txt<weight6_t, 32>(w6, "w6.txt");
        nnet::load_weights_from_txt<bias6_t, 4>(b6, "b6.txt");
        nnet::load_exponent_weights_from_txt<exponent_scale12_t, 4>(s12, "s12.txt");
        nnet::load_weights_from_txt<bias12_t, 4>(b12, "b12.txt");
        nnet::load_weights_from_txt<q_dense_2_weight_t, 8>(w9, "w9.txt");
        nnet::load_weights_from_txt<q_dense_2_bias_t, 2>(b9, "b9.txt");
        loaded_weights = true;
    }
#endif

    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    auto& layer2_out = flatten_input;
    layer3_t layer3_out[N_LAYER_3];
    #pragma HLS ARRAY_PARTITION variable=layer3_out complete dim=0
    nnet::dense<input_t, layer3_t, config3>(layer2_out, layer3_out, w3, b3); // q_dense

    layer11_t layer11_out[N_LAYER_3];
    #pragma HLS ARRAY_PARTITION variable=layer11_out complete dim=0
    nnet::normalize<layer3_t, layer11_t, config11>(layer3_out, layer11_out, s11, b11); // q_dense_alpha

    layer5_t layer5_out[N_LAYER_3];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0
    nnet::relu<layer11_t, layer5_t, relu_config5>(layer11_out, layer5_out); // q_activation

    layer6_t layer6_out[N_LAYER_6];
    #pragma HLS ARRAY_PARTITION variable=layer6_out complete dim=0
    nnet::dense<layer5_t, layer6_t, config6>(layer5_out, layer6_out, w6, b6); // q_dense_1

    layer12_t layer12_out[N_LAYER_6];
    #pragma HLS ARRAY_PARTITION variable=layer12_out complete dim=0
    nnet::normalize<layer6_t, layer12_t, config12>(layer6_out, layer12_out, s12, b12); // q_dense_1_alpha

    layer8_t layer8_out[N_LAYER_6];
    #pragma HLS ARRAY_PARTITION variable=layer8_out complete dim=0
    nnet::relu<layer12_t, layer8_t, relu_config8>(layer12_out, layer8_out); // q_activation_1

    layer9_t layer9_out[N_LAYER_9];
    #pragma HLS ARRAY_PARTITION variable=layer9_out complete dim=0
    nnet::dense<layer8_t, layer9_t, config9>(layer8_out, layer9_out, w9, b9); // q_dense_2

    nnet::softmax<layer9_t, result_t, softmax_config10>(layer9_out, layer10_out); // q_dense_2_softmax

}
