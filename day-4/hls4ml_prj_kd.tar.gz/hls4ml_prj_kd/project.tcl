variable project_name
set project_name "myproject"
variable backend
set backend "vivado"
variable part
set part "xczu3eg-ffvb1156-1-e"
variable clock_period
set clock_period 5
variable clock_uncertainty
set clock_uncertainty 12.5%
variable version
set version "1.0.0"
