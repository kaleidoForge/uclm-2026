//Numpy array shape [1]
//Min 0.015625000000
//Max 0.062500000000
//Number of zeros 0

#ifndef S11_H_
#define S11_H_

#ifndef __SYNTHESIS__
exponent_scale11_t s11[4];
#else
exponent_scale11_t s11[4] = {{1.0, -6}, {1.0, -6}, {1.0, -6}, {1.0, -4}};
#endif

#endif
