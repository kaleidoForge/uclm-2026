//Numpy array shape [2]
//Min -6.751006126404
//Max 6.751007080078
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
q_dense_5_bias_t b9[2];
#else
q_dense_5_bias_t b9[2] = {6.7510070801, -6.7510061264};
#endif

#endif
