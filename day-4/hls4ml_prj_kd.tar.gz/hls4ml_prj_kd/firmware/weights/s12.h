//Numpy array shape [1]
//Min 0.031250000000
//Max 0.250000000000
//Number of zeros 0

#ifndef S12_H_
#define S12_H_

#ifndef __SYNTHESIS__
exponent_scale12_t s12[16];
#else
exponent_scale12_t s12[16] = {{1.0, -3}, {1.0, -5}, {1.0, -4}, {1.0, -3}, {1.0, -5}, {1.0, -3}, {1.0, -3}, {1.0, -3}, {1.0, -3}, {1.0, -3}, {1.0, -5}, {1.0, -3}, {1.0, -2}, {1.0, -3}, {1.0, -3}, {1.0, -4}};
#endif

#endif
