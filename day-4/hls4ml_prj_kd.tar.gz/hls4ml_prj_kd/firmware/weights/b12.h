//Numpy array shape [16]
//Min -1.375000000000
//Max 0.000000000000
//Number of zeros 14

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[16];
#else
bias12_t b12[16] = {0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, -0.125, 0.000, -1.375, 0.000, 0.000, 0.000};
#endif

#endif
