#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,8> input_t;
typedef ap_fixed<16,8> model_default_t;
typedef ap_fixed<33,22> q_dense_3_result_t;
typedef ap_fixed<8,5> weight3_t;
typedef ap_fixed<8,5> bias3_t;
typedef ap_uint<1> layer3_index;
typedef ap_fixed<16,8> q_dense_3_alpha_result_t;
typedef struct exponent_scale11_t {ap_uint<1> sign;ap_int<8> weight; } exponent_scale11_t;
typedef ap_fixed<8,5> bias11_t;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT,0> layer5_t;
typedef ap_fixed<18,8> q_activation_2_table_t;
typedef ap_fixed<19,8> q_dense_4_result_t;
typedef ap_fixed<8,5> weight6_t;
typedef ap_fixed<8,5> bias6_t;
typedef ap_uint<1> layer6_index;
typedef ap_fixed<16,8> q_dense_4_alpha_result_t;
typedef struct exponent_scale12_t {ap_uint<1> sign;ap_int<6> weight; } exponent_scale12_t;
typedef ap_fixed<8,5> bias12_t;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT,0> layer8_t;
typedef ap_fixed<18,8> q_activation_3_table_t;
typedef ap_fixed<29,13> result_t;
typedef ap_fixed<16,8> q_dense_5_weight_t;
typedef ap_fixed<16,8> q_dense_5_bias_t;
typedef ap_uint<1> layer9_index;

// hls-fpga-machine-learning insert emulator-defines


#endif
