//Numpy array shape [2]
//Min -0.533836603165
//Max 0.533851206303
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
q_dense_5_bias_t b9[2];
#else
q_dense_5_bias_t b9[2] = {0.53385121, -0.53383660};

#endif

#endif
