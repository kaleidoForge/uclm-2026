//Numpy array shape [16]
//Min -0.625000000000
//Max 0.750000000000
//Number of zeros 9

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
bias6_t b6[16];
#else
bias6_t b6[16] = {0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000};

#endif

#endif
