//Numpy array shape [4]
//Min 0.000000000000
//Max 0.125000000000
//Number of zeros 2

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[4];
#else
bias11_t b11[4] = {0.125, 0.125, 0.000, 0.000};

#endif

#endif
