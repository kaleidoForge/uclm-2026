//Numpy array shape [16]
//Min -0.625000000000
//Max 0.750000000000
//Number of zeros 9

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[16];
#else
bias12_t b12[16] = {-0.125, 0.000, 0.000, -0.625, 0.125, -0.125, 0.000, 0.000, 0.375, 0.000, 0.750, 0.000, 0.000, 0.000, 0.000, 0.125};

#endif

#endif
