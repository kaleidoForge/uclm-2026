// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xmyproject_auto_accel.h"

extern XMyproject_auto_accel_Config XMyproject_auto_accel_ConfigTable[];

XMyproject_auto_accel_Config *XMyproject_auto_accel_LookupConfig(u16 DeviceId) {
	XMyproject_auto_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMYPROJECT_AUTO_ACCEL_NUM_INSTANCES; Index++) {
		if (XMyproject_auto_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMyproject_auto_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMyproject_auto_accel_Initialize(XMyproject_auto_accel *InstancePtr, u16 DeviceId) {
	XMyproject_auto_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMyproject_auto_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMyproject_auto_accel_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

