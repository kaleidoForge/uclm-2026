#include <iostream>

#include "myproject.h"
#include "parameters.h"


void myproject(
    input_t flatten_input[161],
    result_t layer10_out[2]
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS ARRAY_RESHAPE variable=flatten_input complete dim=0
    #pragma HLS ARRAY_PARTITION variable=layer10_out complete dim=0
    #pragma HLS INTERFACE ap_vld port=flatten_input,layer10_out 
    #pragma HLS PIPELINE off

    // hls-fpga-machine-learning insert load weights
#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<weight3_t, 2576>(w3, "w3.txt");
        nnet::load_weights_from_txt<q_dense_bias_t, 16>(b3, "b3.txt");
        nnet::load_weights_from_txt<weight6_t, 128>(w6, "w6.txt");
        nnet::load_weights_from_txt<q_dense_1_bias_t, 8>(b6, "b6.txt");
        nnet::load_weights_from_txt<q_dense_2_weight_t, 16>(w9, "w9.txt");
        nnet::load_weights_from_txt<q_dense_2_bias_t, 2>(b9, "b9.txt");
        loaded_weights = true;    }
#endif
    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    auto& layer2_out = flatten_input;
    q_dense_result_t layer3_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer3_out complete dim=0

    layer5_t layer5_out[16];
    #pragma HLS ARRAY_PARTITION variable=layer5_out complete dim=0

    q_dense_1_result_t layer6_out[8];
    #pragma HLS ARRAY_PARTITION variable=layer6_out complete dim=0

    layer8_t layer8_out[8];
    #pragma HLS ARRAY_PARTITION variable=layer8_out complete dim=0

    q_dense_2_result_t layer9_out[2];
    #pragma HLS ARRAY_PARTITION variable=layer9_out complete dim=0

    nnet::dense<input_t, q_dense_result_t, config3>(layer2_out, layer3_out, w3, b3); // q_dense

    nnet::relu<q_dense_result_t, layer5_t, relu_config5>(layer3_out, layer5_out); // q_activation

    nnet::dense<layer5_t, q_dense_1_result_t, config6>(layer5_out, layer6_out, w6, b6); // q_dense_1

    nnet::relu<q_dense_1_result_t, layer8_t, relu_config8>(layer6_out, layer8_out); // q_activation_1

    nnet::dense<layer8_t, q_dense_2_result_t, config9>(layer8_out, layer9_out, w9, b9); // q_dense_2

    nnet::softmax<q_dense_2_result_t, result_t, softmax_config10>(layer9_out, layer10_out); // q_dense_2_softmax

}

