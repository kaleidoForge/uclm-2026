//Numpy array shape [8]
//Min -0.093109533191
//Max 0.234986051917
//Number of zeros 1

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
q_dense_1_bias_t b6[8];
#else
q_dense_1_bias_t b6[8] = {0.1423574537, -0.0093425838, -0.0351800509, 0.2349860519, 0.1911603212, 0.0000000000, -0.0931095332, 0.1297994703};

#endif

#endif
