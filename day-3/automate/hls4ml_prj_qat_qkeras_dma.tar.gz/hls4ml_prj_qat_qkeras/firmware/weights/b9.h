//Numpy array shape [2]
//Min -2.177005767822
//Max 2.177010297775
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
q_dense_2_bias_t b9[2];
#else
q_dense_2_bias_t b9[2] = {-2.1770057678, 2.1770102978};

#endif

#endif
