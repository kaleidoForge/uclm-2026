#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,6> input_t;
typedef ap_fixed<16,6> model_default_t;
typedef ap_fixed<33,18> q_dense_result_t;
typedef ap_fixed<8,3> weight3_t;
typedef ap_fixed<16,6> q_dense_bias_t;
typedef ap_uint<1> layer3_index;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT,0> layer5_t;
typedef ap_fixed<18,8> q_activation_table_t;
typedef ap_fixed<21,8> q_dense_1_result_t;
typedef ap_fixed<8,3> weight6_t;
typedef ap_fixed<16,6> q_dense_1_bias_t;
typedef ap_uint<1> layer6_index;
typedef ap_ufixed<8,0,AP_RND_CONV,AP_SAT,0> layer8_t;
typedef ap_fixed<18,8> q_activation_1_table_t;
typedef ap_fixed<28,10> q_dense_2_result_t;
typedef ap_fixed<16,6> q_dense_2_weight_t;
typedef ap_fixed<16,6> q_dense_2_bias_t;
typedef ap_uint<1> layer9_index;
typedef ap_fixed<16,6> result_t;
typedef ap_fixed<18,8> q_dense_2_softmax_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> q_dense_2_softmax_exp_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> q_dense_2_softmax_inv_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> q_dense_2_softmax_inv_inp_t;

// hls-fpga-machine-learning insert emulator-defines


#endif
