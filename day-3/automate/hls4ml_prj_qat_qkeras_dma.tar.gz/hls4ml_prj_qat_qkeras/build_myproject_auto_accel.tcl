
open_project -reset hls4ml_prj_qat_qkeras_accel_prj
set_top myproject_auto_accel

add_files firmware/myproject_auto_accel.cpp -cflags "-std=c++14"
add_files firmware/myproject_auto_accel.h
add_files firmware/myproject.cpp -cflags "-std=c++14"
add_files firmware/myproject.h
add_files firmware/defines.h
add_files firmware/parameters.h
add_files firmware/nnet_utils
add_files firmware/weights

open_solution -reset "solution1"
set_part xczu3eg-sbva484-1-e
create_clock -period 10.0 -name default

csynth_design
export_design -format ip_catalog -version 1.0
exit
